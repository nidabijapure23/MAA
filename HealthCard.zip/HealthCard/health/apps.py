from django.apps import AppConfig


class HealthConfig(AppConfig):
    name = 'health'
